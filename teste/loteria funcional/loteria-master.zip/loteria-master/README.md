# loteria
Consumindo uma api que retorna resultados de sorteios.<br>
Projeto no ar <a href="https://oliveira.dev.br/loteria">aqui</a>
